#include "tui_display.h"
#include <iostream>

TuiDisplay::TuiDisplay() : m_out{std::cout} {}

void TuiDisplay::draw(
    const std::vector<std::vector<std::unique_ptr<Piece>>> &board) {

  std::string rowTitles[] = {"8", "7", "6", "5", "4", "3", "2", "1"};

  m_out << "\n   "
        << "a b c d e f g h\n\n";
  for (size_t i = 0; i < board.size(); ++i) {
    m_out << rowTitles[i] << "  ";
    for (size_t j = 0; j < board[i].size(); ++j) {
      m_out << board[i][j]->getId() << " ";
    }
    m_out << " " << rowTitles[i];
    m_out << "\n";
  }
  m_out << "\n   "
        << "a b c d e f g h\n";

  m_out << std::endl;
}

void TuiDisplay::write(const std::string message) const {
  m_out << message << std::endl;
}

TuiDisplay::~TuiDisplay() {}
