#include "chess_game.h"

int main() {
  ChessGame cg{};
  cg.runSimul();
}
