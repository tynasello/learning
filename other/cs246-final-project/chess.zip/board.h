#pragma once

#include "player.h"
#include "subject.h"
#include <stack>
#include <vector>

class Piece;
class ChessMove;

class Board : public Subject {
  const int m_boardSize = 8;
  std::vector<std::vector<std::unique_ptr<Piece>>> m_squares;
  std::stack<ChessMove> m_previousMoves;
  const bool movePutsPlayerInCheck(const PieceColor &playerColor,
                                   const ChessMove &move) const;
  const bool handleSpecialMove(const ChessMove &move);
  const bool isCastle(const ChessMove &move) const;
  const std::unique_ptr<Piece> getPromotedPiece(const ChessMove &move);
  void performCastle(const ChessMove &move);
  void performEnPassant(const ChessMove &move);
  void performPawnPromotion(const ChessMove &move);

public:
  Board();
  Board(const Board &other);
  const int getBoardSize() const;
  const std::vector<std::vector<std::unique_ptr<Piece>>> &getState() const;
  void placePiece(std::string pieceId, PieceColor pieceColor, const int row,
                  const int col);
  void clearBoard();
  void removePiece(const int row, const int col);
  const bool isMoveValid(const ChessMove &move,
                         const PieceColor &playerColor) const;
  void makeMove(const ChessMove &move);
  void initializeBoard();
  const bool playerIsInCheck(const PieceColor &playerColor) const;
  const bool playerIsInCheckMate(const PieceColor &playerColor) const;
  const bool isBoardInStalemate(const PieceColor &playerColor) const;
  const bool isPieceUnderAttack(const int row, const int col) const;
  const bool isBoardADraw() const;
  const bool isEnPassent(const ChessMove &move) const;
  const bool isPawnPromotion(const ChessMove &move) const;
};
