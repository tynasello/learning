#pragma once

enum class PlayerType { HUMAN, COMPUTER };
