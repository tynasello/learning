#include "gui_display.h"

GuiDisplay::GuiDisplay() : m_window{std::make_unique<Xwindow>()} {
  DrawBoardLayout();
};

void GuiDisplay::draw(
    const std::vector<std::vector<std::unique_ptr<Piece>>> &board) {

  for (size_t row = 0; row < board.size(); ++row) {
    if (board.size() != m_previouslyDisplayedBoard.size()) {
      m_previouslyDisplayedBoard.resize(board.size());
    }
    for (size_t col = 0; col < board.size(); ++col) {
      if (board[col].size() != m_previouslyDisplayedBoard[col].size()) {
        m_previouslyDisplayedBoard[col].resize(board[col].size());
      }
      std::string pieceId = board[row][col].get()->getId();
      if (m_previouslyDisplayedBoard[row][col] != pieceId) {
        m_window->fillRectangle(
            (col + col + BORDER_OFFSET) * GRID_RATIO - GRID_RATIO / 2,
            (row + row + BORDER_OFFSET) * GRID_RATIO - GRID_RATIO,
            1.5 * GRID_RATIO, 1.5 * GRID_RATIO,
            (row + col) % 2 == 0 ? Xwindow::White : Xwindow::Green);
        m_window->drawString((col + col + BORDER_OFFSET) * GRID_RATIO,
                             (row + row + BORDER_OFFSET) * GRID_RATIO, pieceId);
        m_previouslyDisplayedBoard[row][col] = pieceId;
      }
    }
  }
}

void GuiDisplay::DrawBoardLayout() const {
  std::vector<std::string> colTitles{"a", "b", "c", "d", "e", "f", "g", "h"};
  std::vector<std::string> rowTitles{"8", "7", "6", "5", "4", "3", "2", "1"};
  for (size_t col = 0; col < rowTitles.size(); ++col) {
    m_window->drawString((col + col + BORDER_OFFSET) * GRID_RATIO,
                         1 * GRID_RATIO, colTitles[col]);
    m_window->drawString((col + col + BORDER_OFFSET) * GRID_RATIO,
                         (13 + 2 * BORDER_OFFSET) * GRID_RATIO, colTitles[col]);
  }
  for (size_t row = 0; row < rowTitles.size(); ++row) {
    m_window->drawString(1 * GRID_RATIO,
                         (row + row + BORDER_OFFSET) * GRID_RATIO,
                         rowTitles[row]);
    m_window->drawString((13 + 2 * BORDER_OFFSET) * GRID_RATIO,
                         (row + row + BORDER_OFFSET) * GRID_RATIO,
                         rowTitles[row]);
  }
  for (size_t col = 0; col < rowTitles.size(); ++col) {
    for (size_t row = 0; row < rowTitles.size(); ++row) {
      m_window->fillRectangle(
          (col + col + BORDER_OFFSET) * GRID_RATIO - GRID_RATIO / 2,
          (row + row + BORDER_OFFSET) * GRID_RATIO - GRID_RATIO,
          1.5 * GRID_RATIO, 1.5 * GRID_RATIO,
          (col + row) % 2 == 0 ? Xwindow::White : Xwindow::Green);
    }
  }
}

void GuiDisplay::write(const std::string message) const {
  m_window->fillRectangle(0, (13 + 2 * BORDER_OFFSET) * GRID_RATIO,
                          GRID_RATIO * 20, 4 * GRID_RATIO, Xwindow::White);
  m_window->drawString(0, (13 + 3 * BORDER_OFFSET) * GRID_RATIO, message);
}
